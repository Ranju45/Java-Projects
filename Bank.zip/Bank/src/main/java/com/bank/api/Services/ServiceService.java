//package com.bank.api.Services;
//
//
//	import org.springframework.beans.factory.annotation.Autowired;
//	import org.springframework.stereotype.Service;
//
//import com.bank.api.Repo.ServiceRepository;
//
//import java.util.List;
//
//	@Service
//	public class ServiceService {
//
//	    @Autowired
//	    private ServiceRepository serviceRepository;
//
//	    public List<com.bank.api.Entity.Service> getServicesByBankName(String bankName) {
//	        return serviceRepository.findByBankName(bankName);
//	    }
//	}
