package com.bank.api.Controlller;






import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bank.api.Services.BankService;
//
//@Controller
//public class BankController {
//
//    @Autowired
//    private BankService bankService;
//
//    @GetMapping("/bank/branches")
//    public String showBankBranches(@RequestParam("bankId") Long bankId, Model model) {
//        model.addAttribute("bankName", "XYZ Bank");
//        model.addAttribute("branches", bankService.getBankBranches(bankId));
//        return "branches";
//    }
//
//    @GetMapping("/bank/services")
//    public String showBankServices(@RequestParam("bankId") Long bankId, Model model) {
//        model.addAttribute("bankName", "XYZ Bank");
//        model.addAttribute("services", bankService.getBankServices(bankId));
//        return "services";
//    }
//}







@Controller
public class BankController {

    @Autowired
    private BankService bankService;

    // Display a list of bank branches
    @GetMapping("/bank/branches")
    public String showBankBranches(@RequestParam("bankId") Long bankId, Model model) {
        model.addAttribute("bankName", bankService.getBankName(bankId));  // Dynamically fetch bank name
        model.addAttribute("branches", bankService.getBankBranches(bankId));
        return "branches"; // Corresponds to branches.html
    }

    // Display a list of bank services
    @GetMapping("/bank/services")
    public String showBankServices(@RequestParam("bankId") Long bankId, Model model) {
        model.addAttribute("bankName", bankService.getBankName(bankId));  // Dynamically fetch bank name
        model.addAttribute("services", bankService.getBankServices(bankId));
        return "services"; // Corresponds to services.html
    }

    // Display a list of all banks (added for bank.html)
    @GetMapping("/bank/list")
    public String showBanks(Model model) {
        model.addAttribute("banks", bankService.getAllBanks());
        return "banks"; // Corresponds to banks.html
    }
}
