package com.bank.api.Entity;

import jakarta.persistence.*;


//@Entity
//public class Branch {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//    private String name;
//    private String address;
//    
//    @ManyToOne
//    @JoinColumn(name = "bank_id")
//    private Bank bank;
//
//	public Branch() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	public Branch(Long id, String name, String address, Bank bank) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.address = address;
//		this.bank = bank;
//	}
//
//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}
//
//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public String getAddress() {
//		return address;
//	}
//
//	public void setAddress(String address) {
//		this.address = address;
//	}
//
//	public Bank getBank() {
//		return bank;
//	}
//
//	public void setBank(Bank bank) {
//		this.bank = bank;
//	}
//
//    // Constructors, Getters, and Setters
//    
//    
//}





//
//@Entity
//public class Branch {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    private String name;
//    private String address;
//
//    @ManyToOne
//    @JoinColumn(name = "bank_id")
//    private Bank bank;
//
//	public Branch() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	public Branch(Long id, String name, String address, Bank bank) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.address = address;
//		this.bank = bank;
//	}
//
//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}
//
//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public String getAddress() {
//		return address;
//	}
//
//	public void setAddress(String address) {
//		this.address = address;
//	}
//
//	public Bank getBank() {
//		return bank;
//	}
//
//	public void setBank(Bank bank) {
//		this.bank = bank;
//	}
//
//    // Getters and Setters
//    
//    
//    
//}




@Entity
public class Branch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String address;

    private String branchName; // New field added

    @ManyToOne
    @JoinColumn(name = "bank_id")
    private Bank bank;

    // Default constructor
    public Branch() {
        super();
    }

    // Constructor with all fields including branchName
    public Branch(Long id, String name, String address, String branchName, Bank bank) {
        super();
        this.id = id;
        this.name = name;
        this.address = address;
        this.branchName = branchName; // Initialize branchName
        this.bank = bank;
    }

    // Getters and Setters for id
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // Getters and Setters for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getters and Setters for address
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Getters and Setters for branchName
    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    // Getters and Setters for bank
    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }
}
