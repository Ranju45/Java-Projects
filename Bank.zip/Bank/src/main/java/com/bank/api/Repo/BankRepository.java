package com.bank.api.Repo;


import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.api.Entity.Bank;

//public interface BankRepository extends JpaRepository<Bank, Long> {
//    Bank findByName(String name);
//}





import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface BankRepository extends JpaRepository<Bank, Long> {

    // Optional method to find a Bank by its ID
    Optional<Bank> findById(Long id);

    // You can add other custom queries here if needed
}
