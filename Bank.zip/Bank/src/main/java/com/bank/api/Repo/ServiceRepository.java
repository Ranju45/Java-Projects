package com.bank.api.Repo;


import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.api.Entity.Service;

import java.util.List;

//public interface ServiceRepository extends JpaRepository<Service, Long> {
//    List<Service> findByBankName(String bankName);
//}




import java.util.List;

public interface ServiceRepository extends JpaRepository<Service, Long> {
    List<Service> findByBankId(Long bankId);
}
