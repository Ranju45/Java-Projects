//package com.bank.api.Services;
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.bank.api.Entity.Branch;
//import com.bank.api.Repo.BranchRepository;
//
//import java.util.List;
//
//@Service
//public class BranchService {
//
//    @Autowired
//    private BranchRepository branchRepository;
//
//    public List<Branch> getBranchesByBankName(String bankName) {
//        return branchRepository.findByBankName(bankName);
//    }
//}
