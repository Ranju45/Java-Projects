package com.bank.api.Repo;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.api.Entity.Branch;
//
//public interface BranchRepository extends JpaRepository<Branch, Long> {
//    List<Branch> findByBankName(String bankName);
//}






import java.util.List;

public interface BranchRepository extends JpaRepository<Branch, Long> {
    List<Branch> findByBankId(Long bankId);
}
