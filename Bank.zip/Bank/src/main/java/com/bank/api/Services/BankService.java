package com.bank.api.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.api.Entity.Bank;
import com.bank.api.Entity.Branch;
import com.bank.api.Repo.BankRepository;
import com.bank.api.Repo.BranchRepository;
import com.bank.api.Repo.ServiceRepository;

//@Service
//public class BankService {
//
//    @Autowired
//    private BankRepository bankRepository;
//
//    public Bank getBankByName(String bankName) {
//        return bankRepository.findByName(bankName);
//    }
//
//	public List<com.bank.api.Entity.Service> getServicesByBankName(String bankName) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//}







import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BankService {

    @Autowired
    private BranchRepository branchRepository;

    @Autowired
    private ServiceRepository serviceRepository;

    @Autowired
    private BankRepository bankRepository;

    public List<Branch> getBankBranches(Long bankId) {
        return branchRepository.findByBankId(bankId);
    }

    public List<com.bank.api.Entity.Service> getBankServices(Long bankId) {
        return serviceRepository.findByBankId(bankId);
    }

    // Implementing the method to return all banks
    public List<Bank> getAllBanks() {
        return bankRepository.findAll();  // Fetch all banks from the database
    }

    public String getBankName(Long bankId) {
        Bank bank = bankRepository.findById(bankId).orElse(null);
        return bank != null ? bank.getName() : null;
    }
}
